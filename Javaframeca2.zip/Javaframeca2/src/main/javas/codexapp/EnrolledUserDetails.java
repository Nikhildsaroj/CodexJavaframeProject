package codexapp;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "Enrolleduser_details")
public class EnrolledUserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "UserID")
    private int userId;

    @Column(name = "Name")
    private String name;

    @Column(name = "Email")
    private String email;

    @Column(name = "Contact")
    private String contact;

    @Column(name = "course_id")
    private int courseId;

    @Column(name = "course_name")
    private String courseName;

    @Column(name = "instructor")
    private String instructor;

    @Column(name = "course_price")
    private double coursePrice;

    @Column(name = "duration")
    private String duration;

    @Column(name = "enrollment_datetime")
    private Timestamp enrollmentDateTime;

    // Default constructor
    public EnrolledUserDetails() {
    }

    // Parameterized constructor
    public EnrolledUserDetails(int userId, String name, String email, String contact, int courseId, String courseName,
                               String instructor, double coursePrice, String duration, Timestamp enrollmentDateTime) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.contact = contact;
        this.courseId = courseId;
        this.courseName = courseName;
        this.instructor = instructor;
        this.coursePrice = coursePrice;
        this.duration = duration;
        this.enrollmentDateTime = enrollmentDateTime;
    }

    // Getters and setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public double getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(double coursePrice) {
        this.coursePrice = coursePrice;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public Timestamp getEnrollmentDateTime() {
        return enrollmentDateTime;
    }

    public void setEnrollmentDateTime(Timestamp enrollmentDateTime) {
        this.enrollmentDateTime = enrollmentDateTime;
    }

    @Override
    public String toString() {
        return "EnrolledUserDetails{" +
                "userId=" + userId +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", contact='" + contact + '\'' +
                ", courseId=" + courseId +
                ", courseName='" + courseName + '\'' +
                ", instructor='" + instructor + '\'' +
                ", coursePrice=" + coursePrice +
                ", duration='" + duration + '\'' +
                ", enrollmentDateTime=" + enrollmentDateTime +
                '}';
    }
}
