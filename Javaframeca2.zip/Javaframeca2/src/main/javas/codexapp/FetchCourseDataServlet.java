package codexapp;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FetchCourseDataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private SessionFactory factory;

    @Override
    public void init() throws ServletException {
        // Initialize Hibernate SessionFactory
        factory = new Configuration()
                .configure("hibernate.cfg.xml") // Hibernate configuration file
                .addAnnotatedClass(CourseDetails.class)
                .buildSessionFactory();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<CourseDetails> courseList = fetchCourseDataFromDatabase();
        // Set the course list as an attribute in the request
        request.setAttribute("courseList", courseList);

        // Forward the request to coursedata.jsp (or your desired JSP page)
        request.getRequestDispatcher("coursedata.jsp").forward(request, response);
    }

    @Override
    public void destroy() {
        // Close the SessionFactory when the servlet is destroyed
        if (factory != null) {
            factory.close();
        }
    }

    // Method to fetch course data using Hibernate
    private List<CourseDetails> fetchCourseDataFromDatabase() {
        List<CourseDetails> courseList = null;

        // Open a session
        try (Session session = factory.getCurrentSession()) {
            session.beginTransaction();
            // Fetch all course details using HQL (Hibernate Query Language)
            courseList = session.createQuery("from CourseDetails", CourseDetails.class).getResultList();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        }

        return courseList;
    }
}
