package codexapp;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;



public class FetchUserDataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Initialize Hibernate session factory
    private SessionFactory sessionFactory;

    @Override
    public void init() throws ServletException {
        try {
            // Build the Hibernate SessionFactory from the configuration file
            sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        } catch (Exception e) {
            throw new ServletException("Hibernate session factory initialization failed", e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<User> userList = fetchUserDataFromDatabase();

        // Set the user list as an attribute in the request
        request.setAttribute("userList", userList);

        // Forward the request to userdata.jsp
        request.getRequestDispatcher("userdata.jsp").forward(request, response);
    }

    // Method to fetch user data using Hibernate
    private List<User> fetchUserDataFromDatabase() {
        List<User> userList = null;

        // Open a Hibernate session
        try (Session session = sessionFactory.openSession()) {
            // Begin a transaction
            session.beginTransaction();

            // Query the database for all users using HQL (Hibernate Query Language)
            Query<User> query = session.createQuery("FROM User", User.class);
            userList = query.getResultList();

            // Commit the transaction
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return userList;
    }

    @Override
    public void destroy() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
