package codexapp;

import org.hibernate.Session;
import org.hibernate.query.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/FetchEnrollmentDataServlet")
public class FetchEnrollmentDataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<EnrollmentDetails> enrollmentList = fetchEnrollmentDataFromDatabase();

        // Set the enrollment list as an attribute in the request
        request.setAttribute("enrollmentList", enrollmentList);

        // Forward the request to enrollmentdata.jsp
        request.getRequestDispatcher("enrollmentdata.jsp").forward(request, response);
    }

    // Method to fetch enrollment data from the database using Hibernate
    private List<EnrollmentDetails> fetchEnrollmentDataFromDatabase() {
        List<EnrollmentDetails> enrollmentList = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();

            // Create and execute the HQL query
            String hql = "FROM EnrollmentDetails";
            Query<EnrollmentDetails> query = session.createQuery(hql, EnrollmentDetails.class);
            enrollmentList = query.getResultList();

            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        }

        return enrollmentList;
    }
}
