package codexapp;

import org.hibernate.Session;
import org.hibernate.Transaction;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.io.IOException;

@WebServlet("/DeleteCourseServlet")
public class DeleteCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            CourseDetails course = session.get(CourseDetails.class, courseId);

            if (course != null) {
                session.delete(course);
                transaction.commit();

                request.setAttribute("confirmationMessage", "Course deleted successfully!");
                RequestDispatcher dispatcher = request.getRequestDispatcher("course_deleted_confirmation.jsp");
                dispatcher.forward(request, response);
            } else {
                // Course with the specified ID not found
                response.sendRedirect("FetchCourseDataServlet?status=failed");
            }
        } catch (Exception e) {
            if (transaction != null) {
                try {
                    transaction.rollback();
                } catch (Exception rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
