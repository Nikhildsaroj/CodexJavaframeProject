package codexapp;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import javax.mail.*;
import javax.mail.internet.*;
import java.time.LocalDateTime;

@WebServlet("/InsertVipServlet")
public class InsertVipServlet extends HttpServlet {

    private SessionFactory factory;

    @Override
    public void init() throws ServletException {
        super.init();
        factory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .addAnnotatedClass(VipMember.class)
                    .buildSessionFactory();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String membershipPlan = request.getParameter("membershipPlan");
        String paymentMethod = request.getParameter("paymentMethod");
        
        String cardNumber = request.getParameter("cardNumber");
        String expiryDate = request.getParameter("expiryDate");
        String cvv = request.getParameter("cvv");
        String upiId = request.getParameter("upiId");
        String paytmNumber = request.getParameter("paytmNumber");
        String googlePayNumber = request.getParameter("googlePayNumber");

        String vipKey = generateVipKey();

        VipMember vipMember = new VipMember();
        vipMember.setFullName(fullName);
        vipMember.setEmailAddress(email);
        vipMember.setMembershipPlan(VipMember.MembershipPlan.valueOf(membershipPlan));
        vipMember.setPaymentMethod(VipMember.PaymentMethod.valueOf(paymentMethod));

        setPaymentMethodDetails(vipMember, paymentMethod, cardNumber, expiryDate, cvv, upiId, paytmNumber, googlePayNumber);
        
        vipMember.setVipKey(vipKey);
        vipMember.setCreatedAt(LocalDateTime.now());

        saveVipMember(vipMember);

        request.setAttribute("email", email);
        request.setAttribute("fullName", fullName);
        request.setAttribute("vipKey", vipKey);
        request.setAttribute("membershipPlan", membershipPlan);
        request.setAttribute("paymentMethod", paymentMethod);
        request.setAttribute("cardNumber", cardNumber);
        request.setAttribute("expiryDate", expiryDate);
        request.setAttribute("cvv", cvv);
        request.setAttribute("upiId", upiId);
        request.setAttribute("paytmNumber", paytmNumber);
        request.setAttribute("googlePayNumber", googlePayNumber);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/vipmail.jsp");
        dispatcher.forward(request, response);
    }

    private String generateVipKey() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder vipKey = new StringBuilder(9);
        Random random = new Random();
        for (int i = 0; i < 9; i++) {
            vipKey.append(chars.charAt(random.nextInt(chars.length())));
        }
        return vipKey.toString();
    }

    private void setPaymentMethodDetails(VipMember vipMember, String paymentMethod, String cardNumber, String expiryDate, String cvv,
                                         String upiId, String paytmNumber, String googlePayNumber) {
        switch (paymentMethod) {
            case "CREDIT_CARD":
                vipMember.setCardNumber(cardNumber);
                vipMember.setCardExpiryDate(expiryDate);
                vipMember.setCardCvv(cvv);
                break;
            case "UPI":
                vipMember.setUpiId(upiId);
                break;
            case "PAYTM":
                vipMember.setPaytmNumber(paytmNumber);
                break;
            case "GOOGLE_PAY":
                vipMember.setGooglePayNumber(googlePayNumber);
                break;
            default:
                throw new IllegalArgumentException("Invalid payment method: " + paymentMethod);
        }
    }

    private void saveVipMember(VipMember vipMember) {
        Session session = factory.openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            session.save(vipMember);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
    
    @Override
    public void destroy() {
        if (factory != null) {
            factory.close();
        }
        super.destroy();
    }
}
