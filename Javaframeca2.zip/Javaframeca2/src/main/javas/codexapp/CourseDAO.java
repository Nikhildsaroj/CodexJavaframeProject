package codexapp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {
    // Assuming an empty password for the root user
    private static final String jdbcUrl = "jdbc:mysql://localhost:3307/Codex";
    private static final String username = "root";
    private static final String password = "root12"; // Empty password

    public List<Course> getPaidCourses() {
        List<Course> paidCourses = new ArrayList<>();
        String sql = "SELECT * FROM coursesdetails";

        try (Connection connection = DatabaseUtil.getConnection(jdbcUrl, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Course course = new Course(
                        resultSet.getInt("courseID"),
                        resultSet.getString("CourseName"),
                        resultSet.getString("CourseDescription"),
                        resultSet.getString("Instructor"),
                        resultSet.getDouble("CoursePrice"),
                        resultSet.getString("Duration")
                        // Add other course details as needed
                );

                paidCourses.add(course);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions appropriately
        }

        return paidCourses;
    }

    // Other methods for handling course-related database operations
}
