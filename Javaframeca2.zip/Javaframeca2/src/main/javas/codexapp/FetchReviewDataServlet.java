package codexapp;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/FetchReviewDataServlet")
public class FetchReviewDataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private SessionFactory sessionFactory;

    @Override
    public void init() throws ServletException {
        // Initialize Hibernate SessionFactory
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Set the content type to HTML
        response.setContentType("text/html;charset=UTF-8");

        // Get the PrintWriter to write the HTML response
        PrintWriter out = response.getWriter();

        // Fetch the review data
        List<Review> reviewList = fetchReviewDataFromDatabase();

        // Write the HTML response directly
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Review Data</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; background-color: #f8f9fa; padding: 20px; }");
        out.println("h2 { color: #007bff; margin-bottom: 30px; }");
        out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; }");
        out.println("th, td { border: 1px solid #dee2e6; padding: 15px; text-align: left; }");
        out.println("th { background-color: #007bff; color: #ffffff; }");
        out.println("tr:hover { background-color: #f8f9fa; }");
        out.println(".table .thead-dark th { color: #fff; background-color: #343a40; border-color: #454d55; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");

        out.println("<div class=\"container mt-5\">");
        out.println("<h2>Review Data</h2>");

        out.println("<table class=\"table table-bordered\">");
        out.println("<thead class=\"thead-dark\">");
        out.println("<tr>");
        out.println("<th>Review ID</th>");
        out.println("<th>User Name</th>");
        out.println("<th>Email</th>");
        out.println("<th>Rating</th>");
        out.println("<th>Overall Experience</th>");
        out.println("<th>Recommendation</th>");
        out.println("<th>Improvements</th>");
        out.println("<th>Submission Date</th>");
        out.println("</tr>");
        out.println("</thead>");
        out.println("<tbody>");

        // Process the review list and write table rows
        for (Review review : reviewList) {
            out.println("<tr>");
            out.println("<td>" + review.getReviewId() + "</td>");
            out.println("<td>" + review.getUserName() + "</td>");
            out.println("<td>" + review.getEmail() + "</td>");
            out.println("<td>" + review.getRating() + "</td>");
            out.println("<td>" + review.getOverallExperience() + "</td>");
            out.println("<td>" + review.getRecommendation() + "</td>");
            out.println("<td>" + review.getImprovements() + "</td>");
            out.println("<td>" + review.getSubmissionDateTime() + "</td>");
            out.println("</tr>");
        }

        out.println("</tbody>");
        out.println("</table>");
        out.println("</div>");

        out.println("</body>");
        out.println("</html>");
    }

    // Method to fetch review data from the database using Hibernate
    private List<Review> fetchReviewDataFromDatabase() {
        List<Review> reviewList = null;

        // Start a new session and transaction
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            // Fetch the review data
            reviewList = session.createQuery("from Review", Review.class).getResultList();

            // Commit transaction
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        }

        return reviewList;
    }

    @Override
    public void destroy() {
        // Clean up resources
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
