package codexapp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "vip_members")
public class VipMember {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Column(name = "email_address", nullable = false, unique = true)
    private String emailAddress;

    @Enumerated(EnumType.STRING)
    @Column(name = "membership_plan", nullable = false)
    private MembershipPlan membershipPlan;

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_method", nullable = false)
    private PaymentMethod paymentMethod;

    @Column(name = "card_number")
    private String cardNumber;

    @Column(name = "card_expiry_date")
    private String cardExpiryDate;

    @Column(name = "card_cvv")
    private String cardCvv;

    @Column(name = "upi_id")
    private String upiId;

    @Column(name = "paytm_number")
    private String paytmNumber;

    @Column(name = "google_pay_number")
    private String googlePayNumber;

    @Column(name = "vip_key", nullable = false)
    private String vipKey;

    @Column(name = "created_at", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime createdAt = LocalDateTime.now();

    // Constructors
    public VipMember() {}

    public VipMember(String fullName, String emailAddress, MembershipPlan membershipPlan, 
                     PaymentMethod paymentMethod, String vipKey) {
        this.fullName = fullName;
        this.emailAddress = emailAddress;
        this.membershipPlan = membershipPlan;
        this.paymentMethod = paymentMethod;
        this.vipKey = vipKey;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public MembershipPlan getMembershipPlan() {
        return membershipPlan;
    }

    public void setMembershipPlan(MembershipPlan membershipPlan) {
        this.membershipPlan = membershipPlan;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardExpiryDate() {
        return cardExpiryDate;
    }

    public void setCardExpiryDate(String cardExpiryDate) {
        this.cardExpiryDate = cardExpiryDate;
    }

    public String getCardCvv() {
        return cardCvv;
    }

    public void setCardCvv(String cardCvv) {
        this.cardCvv = cardCvv;
    }

    public String getUpiId() {
        return upiId;
    }

    public void setUpiId(String upiId) {
        this.upiId = upiId;
    }

    public String getPaytmNumber() {
        return paytmNumber;
    }

    public void setPaytmNumber(String paytmNumber) {
        this.paytmNumber = paytmNumber;
    }

    public String getGooglePayNumber() {
        return googlePayNumber;
    }

    public void setGooglePayNumber(String googlePayNumber) {
        this.googlePayNumber = googlePayNumber;
    }

    public String getVipKey() {
        return vipKey;
    }

    public void setVipKey(String vipKey) {
        this.vipKey = vipKey;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    // Enums for Membership Plan and Payment Method
    public enum MembershipPlan {
        BASIC, STANDARD, PREMIUM
    }

    public enum PaymentMethod {
        CREDIT_CARD, UPI, PAYTM, GOOGLE_PAY
    }
}

