package codexapp;

import java.io.IOException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditCourseServlet")
public class EditCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static SessionFactory sessionFactory;

    @Override
    public void init() throws ServletException {
        // Initialize the SessionFactory
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the course ID from the request parameter
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        // Fetch the course details from the database
        CourseDetails course = fetchCourseFromDatabase(courseId);

        if (course != null) {
            // Set the course as an attribute in the request
            request.setAttribute("course", course);

            // Forward the request to editcourse.jsp
            request.getRequestDispatcher("editcourse.jsp").forward(request, response);
        } else {
            // Handle the case where the course was not found
            response.getWriter().println("Course not found.");
        }
    }

    // Method to fetch course details from the database using Hibernate
    private CourseDetails fetchCourseFromDatabase(int courseId) {
        CourseDetails course = null;
        Session session = null;
        Transaction transaction = null;

        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();

            // HQL query to select the course based on the course ID
            String hql = "FROM CourseDetails WHERE courseId = :courseId";
            Query<CourseDetails> query = session.createQuery(hql, CourseDetails.class);
            query.setParameter("courseId", courseId);

            // Fetch the course
            course = query.uniqueResult();

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace(); // Handle exceptions properly in a real application
        } finally {
            if (session != null) session.close();
        }

        return course;
    }

    @Override
    public void destroy() {
        // Clean up resources
        if (sessionFactory != null) sessionFactory.close();
    }
}
