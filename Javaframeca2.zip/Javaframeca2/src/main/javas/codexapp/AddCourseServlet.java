package codexapp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addCourse")
public class AddCourseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve data from the form
        String courseName = request.getParameter("courseName");
        String courseDescription = request.getParameter("courseDescription");
        double coursePrice = Double.parseDouble(request.getParameter("coursePrice"));
        String instructor = request.getParameter("instructor");
        String duration = request.getParameter("duration");

        String jdbcUrl = "jdbc:mysql://localhost:3307/Codex";
        String dbUser = "root";
        String dbPassword = "root12";

        try (Connection connection = DatabaseUtil.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Insert the new course into the database
            String sql = "INSERT INTO Coursesdetails (CourseName, CourseDescription, CoursePrice, Instructor, Duration) "
                    + "VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, courseName);
                preparedStatement.setString(2, courseDescription);
                preparedStatement.setDouble(3, coursePrice);
                preparedStatement.setString(4, instructor);
                preparedStatement.setString(5, duration);

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    // Course added successfully
                    request.setAttribute("confirmationMessage", "Course added successfully!");
                    request.getRequestDispatcher("course_confirmation.jsp").forward(request, response);
                } else {
                    // Failed to add course
                    response.sendRedirect("adminpanel.jsp?status=failed");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Redirect to an error page in case of a database exception
            response.sendRedirect("error.jsp");
        }
    }
}
