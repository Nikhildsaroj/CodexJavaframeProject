package codexapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EnrollmentServlet")
public class EnrollmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the Course ID from the request parameter
        String courseIdParameter = request.getParameter("courseId");

        if (courseIdParameter != null && !courseIdParameter.isEmpty()) {
            try {
                int courseId = Integer.parseInt(courseIdParameter);

                // TODO: Establish a database connection (you may use a connection pool for better performance)
                String jdbcUrl = "jdbc:mysql://localhost:3307/codex";
                String dbUsername = "root";
                String dbPassword = "root12";

                try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword)) {
                    String query = "SELECT * FROM coursesdetails WHERE CourseID = ?";
                    try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                        preparedStatement.setInt(1, courseId);
                        try (ResultSet resultSet = preparedStatement.executeQuery()) {
                            if (resultSet.next()) {
                                // Populate the course details from the ResultSet
                                String courseName = resultSet.getString("CourseName");
                                String instructor = resultSet.getString("Instructor");
                                double coursePrice = resultSet.getDouble("CoursePrice");
                                String duration = resultSet.getString("Duration"); // Assuming "Duration" is a String, modify data type if needed

                                // Create a JSON-like response
                                String jsonResponse = "{"
                                        + "\"courseId\":" + courseId + ","
                                        + "\"courseName\":\"" + courseName + "\","
                                        + "\"instructor\":\"" + instructor + "\","
                                        + "\"coursePrice\":" + coursePrice + ","
                                        + "\"duration\":\"" + duration + "\""
                                        + "}";

                                // Set content type and write the JSON response
                                response.setContentType("application/json");
                                PrintWriter out = response.getWriter();
                                out.print(jsonResponse);
                                out.flush();
                            } else {
                                // Handle the case where no course is found with the given ID
                                request.setAttribute("error", "No course found with the given ID");
                                RequestDispatcher dispatcher = request.getRequestDispatcher("/error.jsp");
                                dispatcher.forward(request, response);
                            }
                        }
                    }
                } catch (SQLException e) {
                    // Handle database connection or query execution errors
                    e.printStackTrace();
                    request.setAttribute("error", "Database error");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/error.jsp");
                    dispatcher.forward(request, response);
                }
            } catch (NumberFormatException e) {
                // Handle the NumberFormatException
                e.printStackTrace();
                request.setAttribute("error", "Invalid course ID format");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/error.jsp");
                dispatcher.forward(request, response);
            }
        } else {
            // Handle the case where the input string is empty
            request.setAttribute("error", "Course ID is required");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/error.jsp");
            dispatcher.forward(request, response);
        }
    }
}
