package codexapp;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class signup extends HttpServlet {

    private SessionFactory factory;

    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize Hibernate session factory
        factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(User.class).buildSessionFactory();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact");
        String password = request.getParameter("password");

        // Create a new User object
        User user = new User(name, email, contact, password);

        // Save user data in the database
        saveUser(user);

        // Set attributes for sending confirmation email
        request.setAttribute("name", name);
        request.setAttribute("email", email);

        // Forward to sendmail.jsp for sending confirmation email
        RequestDispatcher dispatcher = request.getRequestDispatcher("/sendmail.jsp");
        dispatcher.forward(request, response);
    }

    private void saveUser(User user) {
        Session session = factory.openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            // Save the user object
            session.save(user);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    @Override
    public void destroy() {
        // Close Hibernate session factory during servlet shutdown
        factory.close();
        super.destroy();
    }
}
