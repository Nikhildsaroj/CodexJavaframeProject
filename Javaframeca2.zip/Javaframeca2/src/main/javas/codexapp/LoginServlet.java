package codexapp;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final String ATTRIBUTE_USER_EMAIL = "userEmail";
    private static final String ATTRIBUTE_USER_NAME = "userName";
    private static final String ATTRIBUTE_ERROR = "error";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Load Hibernate SessionFactory
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(User.class).buildSessionFactory();

        // Open a new session and transaction
        try (Session session = factory.openSession()) {
            Transaction transaction = session.beginTransaction();

            // Use Hibernate Query Language (HQL) to find the user
            String hql = "FROM User U WHERE U.email = :email AND U.password = :password";
            Query<User> query = session.createQuery(hql, User.class);
            query.setParameter("email", email);
            query.setParameter("password", password);

            User user = query.uniqueResult();

            transaction.commit();

            if (user != null) {
                // Valid login, set user session and redirect to home.jsp
                HttpSession httpSession = request.getSession();
                httpSession.setAttribute(ATTRIBUTE_USER_EMAIL, user.getEmail());
                httpSession.setAttribute(ATTRIBUTE_USER_NAME, user.getName());

                // Set response headers to prevent caching
                response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
                response.addHeader("Cache-Control", "post-check=0, pre-check=0");
                response.setHeader("Pragma", "no-cache");
                response.setHeader("Expires", "0");

                response.sendRedirect("home.jsp");
            } else {
                // Invalid login, redirect to login.jsp with an error message
                response.sendRedirect("login.jsp?" + ATTRIBUTE_ERROR + "=invalid");
            }
        } catch (Exception e) {
            // Log the exception and redirect to an error page
            log("Exception in LoginServlet", e);
            response.sendRedirect("error.jsp");
        } finally {
            // Close the factory
            factory.close();
        }
    }
}

