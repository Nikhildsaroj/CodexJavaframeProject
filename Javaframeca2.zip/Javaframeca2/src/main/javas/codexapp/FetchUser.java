package codexapp;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class FetchUser extends HttpServlet {
    private SessionFactory factory;

    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize Hibernate session factory
        factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(User.class).buildSessionFactory();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch users
        List<User> users = fetchUsers();

        // Set the users list in request scope
        request.setAttribute("users", users);

        // Forward to JSP page
        RequestDispatcher dispatcher = request.getRequestDispatcher("/displayuserdata.jsp");
        dispatcher.forward(request, response);
    }

    private List<User> fetchUsers() {
        Session session = factory.openSession();
        List<User> users = null;
        
        try {
            users = session.createQuery("from User", User.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return users;
    }

    @Override
    public void destroy() {
        // Close Hibernate session factory during servlet shutdown
        factory.close();
        super.destroy();
    }
}
