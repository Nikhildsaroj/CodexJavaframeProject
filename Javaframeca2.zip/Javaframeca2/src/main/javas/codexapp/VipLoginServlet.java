package codexapp;

import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.io.IOException;

@WebServlet("/VipLoginServlet")
public class VipLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Hibernate session factory
    private static SessionFactory sessionFactory;

    @Override
    public void init() {
        sessionFactory = HibernateUtil.getSessionFactory();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fullName = request.getParameter("fullName");
        String vipKey = request.getParameter("vipKey");

        Session session = null;
        Transaction transaction = null;

        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();

            // Query to find VIP members by fullName
            Query<VipMember> query = session.createQuery("FROM VipMember WHERE fullName = :fullName", VipMember.class);
            query.setParameter("fullName", fullName);

            List<VipMember> vipMembers = query.list();  // Get list of results

            if (vipMembers.size() == 1) {
                VipMember vipMember = vipMembers.get(0);
                if (vipMember.getVipKey().equals(vipKey)) {
                    HttpSession httpSession = request.getSession();
                    httpSession.setAttribute("fullName", fullName);
                    httpSession.setAttribute("vipKey", vipKey);
                    response.sendRedirect("aivippage.html");
                } else {
                    response.getWriter().write("Invalid VIP Key. Please try again.");
                }
            } else if (vipMembers.size() > 1) {
                throw new org.hibernate.NonUniqueResultException(vipMembers.size());
            } else {
                response.getWriter().write("Invalid Full Name. Please try again.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        } finally {
            if (session != null) session.close();
        }
    }
}
