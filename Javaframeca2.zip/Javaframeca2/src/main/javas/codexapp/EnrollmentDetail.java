package codexapp;



import java.sql.Timestamp;

public class EnrollmentDetail {
    private int enrollmentId;
    private String fullName;
    private String email;
    private String phoneNumber;
    private String city;
    private String state;
    private String country;
    private String dateOfBirth;
    private String gender;
    private String languagePreferences;
    private int courseId;
    private String courseName;
    private String instructor;
    private double coursePrice;
    private String duration;
    private Timestamp enrollmentDateTime;

    // Default constructor
    public EnrollmentDetail() {
    }

    // Parameterized constructor
    public EnrollmentDetail(int enrollmentId, String fullName, String email, String phoneNumber, String city,
                             String state, String country, String dateOfBirth, String gender,
                             String languagePreferences, int courseId, String courseName, String instructor,
                             double coursePrice, String duration, Timestamp enrollmentDateTime) {
        this.enrollmentId = enrollmentId;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.city = city;
        this.state = state;
        this.country = country;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.languagePreferences = languagePreferences;
        this.courseId = courseId;
        this.courseName = courseName;
        this.instructor = instructor;
        this.coursePrice = coursePrice;
        this.duration = duration;
        this.enrollmentDateTime = enrollmentDateTime;
    }

    // Getter and Setter methods
    public int getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(int enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLanguagePreferences() {
        return languagePreferences;
    }

    public void setLanguagePreferences(String languagePreferences) {
        this.languagePreferences = languagePreferences;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public double getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(double coursePrice) {
        this.coursePrice = coursePrice;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public Timestamp getEnrollmentDateTime() {
        return enrollmentDateTime;
    }

    public void setEnrollmentDateTime(Timestamp enrollmentDateTime) {
        this.enrollmentDateTime = enrollmentDateTime;
    }
}

