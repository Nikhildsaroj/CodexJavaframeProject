package codexapp;

import javax.persistence.*;

@Entity
@Table(name = "coursesdetails")
public class CourseDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CourseID")
    private int courseId;

    @Column(name = "CourseName", nullable = false)
    private String courseName;

    @Column(name = "CourseDescription", nullable = false, columnDefinition = "TEXT")
    private String courseDescription;

    @Column(name = "CoursePrice", nullable = false)
    private double coursePrice;

    @Column(name = "Instructor", nullable = false)
    private String instructor;

    @Column(name = "Duration", nullable = false)
    private String duration;

    // Default constructor
    public CourseDetails() {}

    // Parameterized constructor
    public CourseDetails(String courseName, String courseDescription, double coursePrice, String instructor, String duration) {
        this.courseName = courseName;
        this.courseDescription = courseDescription;
        this.coursePrice = coursePrice;
        this.instructor = instructor;
        this.duration = duration;
    }

    // Getters and setters
    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public double getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(double coursePrice) {
        this.coursePrice = coursePrice;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
