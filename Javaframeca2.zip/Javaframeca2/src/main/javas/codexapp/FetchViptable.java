package codexapp;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/FetchViptable")
public class FetchViptable extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private SessionFactory sessionFactory;

    @Override
    public void init() throws ServletException {
        // Initialize Hibernate SessionFactory
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Set the content type to HTML
        response.setContentType("text/html;charset=UTF-8");

        // Get the PrintWriter to write the HTML response
        PrintWriter out = response.getWriter();

        // Fetch the VIP member data
        List<VipMember> vipMemberList = fetchVipMemberDataFromDatabase();

        // Write the HTML response directly
        out.println("<html>");
        out.println("<head>");
        out.println("<title>VIP Member Data</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; background-color: #f8f9fa; padding: 20px; }");
        out.println("h2 { color: #007bff; margin-bottom: 30px; }");
        out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; }");
        out.println("th, td { border: 1px solid #dee2e6; padding: 15px; text-align: left; }");
        out.println("th { background-color: #007bff; color: #ffffff; }");
        out.println("tr:hover { background-color: #f8f9fa; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");

        out.println("<div class=\"container mt-5\">");
        out.println("<h2>VIP Member Data</h2>");
        out.println("<h4>Basic - $9.99/month,Standard - $13.99/month,Premium - $17.99/month</h4>");
       
        
       
        out.println("<table>");
        out.println("<thead>");
        out.println("<tr>");
        out.println("<th>ID</th>");
        out.println("<th>Full Name</th>");
        out.println("<th>Email</th>");
        out.println("<th>Membership Plan</th>");
        out.println("<th>Payment Method</th>");
        
        out.println("<th>VIP Key</th>");
        out.println("<th>Created At</th>");
        out.println("</tr>");
        out.println("</thead>");
        out.println("<tbody>");

        // Process the VIP member list and write table rows
        for (VipMember vipMember : vipMemberList) {
            out.println("<tr>");
            out.println("<td>" + vipMember.getId() + "</td>");
            out.println("<td>" + vipMember.getFullName() + "</td>");
            out.println("<td>" + vipMember.getEmailAddress() + "</td>");
            out.println("<td>" + vipMember.getMembershipPlan() + "</td>");
            out.println("<td>" + vipMember.getPaymentMethod() + "</td>");
           
            out.println("<td>" + vipMember.getVipKey() + "</td>");
            out.println("<td>" + vipMember.getCreatedAt() + "</td>");
            out.println("</tr>");
        }

        out.println("</tbody>");
        out.println("</table>");
        out.println("</div>");

        out.println("</body>");
        out.println("</html>");
    }

    // Method to fetch VIP member data from the database using Hibernate
    private List<VipMember> fetchVipMemberDataFromDatabase() {
        List<VipMember> vipMemberList = null;

        // Start a new session and transaction
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            // Fetch the VIP member data
            vipMemberList = session.createQuery("from VipMember", VipMember.class).getResultList();

            // Commit transaction
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        }

        return vipMemberList;
    }

    @Override
    public void destroy() {
        // Clean up resources
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
