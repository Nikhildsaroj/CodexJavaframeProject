package codexapp;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter("/admin/*") // Specify the URL pattern for which this filter should be applied
public class AdminSessionFilter implements Filter {

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
	        throws IOException, ServletException {
	    HttpServletRequest httpRequest = (HttpServletRequest) request;
	    HttpServletResponse httpResponse = (HttpServletResponse) response;

	    HttpSession session = httpRequest.getSession(false); // Do not create a new session if it doesn't exist

	    boolean isLoggedIn = session != null && session.getAttribute("adminUsername") != null;

	    if (isLoggedIn) {
	        // Admin is logged in, allow the request to proceed
	        chain.doFilter(request, response);
	    } else {
	        // Admin is not logged in, redirect to login page
	        httpResponse.sendRedirect(httpRequest.getContextPath() + "/adminlogin.jsp");
	    }
	}



    public void init(FilterConfig fConfig) throws ServletException {
        // Initialization code, if needed
    }

    public void destroy() {
        // Cleanup code, if needed
    }
}
