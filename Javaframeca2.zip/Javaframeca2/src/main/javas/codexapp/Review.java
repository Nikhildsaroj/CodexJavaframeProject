package codexapp;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name = "detailed_reviews")
public class Review implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "review_id")
    private int reviewId;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "email")
    private String email;

    @Column(name = "rating")
    private int rating;

    @Column(name = "overall_experience")
    private String overallExperience;

    @Column(name = "recommendation")
    private String recommendation;

    @Column(name = "improvements", columnDefinition = "TEXT")
    private String improvements;

    @Column(name = "submissionDateTime", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp submissionDateTime;

    // Default constructor
    public Review() {
        this.submissionDateTime = new Timestamp(System.currentTimeMillis());
    }

    // Parameterized constructor
    public Review(String userName, String email, int rating, String overallExperience, String recommendation, String improvements) {
        this.userName = userName;
        this.email = email;
        this.rating = rating;
        this.overallExperience = overallExperience;
        this.recommendation = recommendation;
        this.improvements = improvements;
        this.submissionDateTime = new Timestamp(System.currentTimeMillis());
    }

    // Getters and Setters
    public int getReviewId() {
        return reviewId;
    }

    public void setReviewId(int reviewId) {
        this.reviewId = reviewId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getOverallExperience() {
        return overallExperience;
    }

    public void setOverallExperience(String overallExperience) {
        this.overallExperience = overallExperience;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public String getImprovements() {
        return improvements;
    }

    public void setImprovements(String improvements) {
        this.improvements = improvements;
    }

    public Timestamp getSubmissionDateTime() {
        return submissionDateTime;
    }

    public void setSubmissionDateTime(Timestamp submissionDateTime) {
        this.submissionDateTime = submissionDateTime;
    }
}
