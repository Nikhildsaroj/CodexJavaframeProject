package codexapp;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.hibernate.cfg.Configuration;

@WebServlet("/UpdateCourseServlet")
public class UpdateCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve data from the form
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        String courseName = request.getParameter("courseName");
        String courseDescription = request.getParameter("courseDescription");
        double coursePrice = Double.parseDouble(request.getParameter("coursePrice"));
        String instructor = request.getParameter("instructor");
        String duration = request.getParameter("duration");

        // Create Hibernate session
        Session session = null;
        Transaction transaction = null;
        try {
            // Obtain Hibernate session from configuration
            session = HibernateUtil.getSessionFactory().openSession();
            transaction = session.beginTransaction();

            // Fetch the course to update
            CourseDetails course = session.get(CourseDetails.class, courseId);

            if (course != null) {
                // Update course details
                course.setCourseName(courseName);
                course.setCourseDescription(courseDescription);
                course.setCoursePrice(coursePrice);
                course.setInstructor(instructor);
                course.setDuration(duration);

                // Save the updated course
                session.update(course);
                transaction.commit();

                // Redirect to success page
                response.sendRedirect("FetchCourseDataServlet?status=success");
            } else {
                // Handle the case where the course was not found
                response.sendRedirect("coursedata.jsp?status=failed");
            }
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            // Redirect to an error page in case of a database exception
            response.sendRedirect("error.jsp");
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
}
