package codexapp;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

@WebServlet("/EnrolledUsersServlet")
public class EnrolledUsersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static SessionFactory sessionFactory;

    @Override
    public void init() throws ServletException {
        // Initialize Hibernate SessionFactory
        sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    }

    @Override
    public void destroy() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<EnrolledUserDetails> enrolledUserList = fetchEnrolledUserDataFromDatabase();

        // Set the enrolled user list as an attribute in the request
        request.setAttribute("enrolledUserList", enrolledUserList);

        // Forward the request to enrolledusers.jsp
        request.getRequestDispatcher("enrolledusers.jsp").forward(request, response);
    }

    // Method to fetch enrolled user data from the database
    private List<EnrolledUserDetails> fetchEnrolledUserDataFromDatabase() {
        List<EnrolledUserDetails> enrolledUserList = null;

        // Obtain session from SessionFactory
        try (Session session = sessionFactory.openSession()) {
            // Create a query to fetch all enrolled user details
            Query<EnrolledUserDetails> query = session.createQuery("FROM EnrolledUserDetails", EnrolledUserDetails.class);
            enrolledUserList = query.list();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        }

        return enrolledUserList;
    }
}
