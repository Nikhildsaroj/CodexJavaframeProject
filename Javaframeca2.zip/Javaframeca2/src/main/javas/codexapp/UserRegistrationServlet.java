package codexapp;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class UserRegistrationServlet extends HttpServlet {

    private SessionFactory factory;

    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize Hibernate session factory
        factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(EnrollmentDetails.class).buildSessionFactory();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phoneNumber = request.getParameter("phoneNumber");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String country = request.getParameter("country");
        String dateOfBirth = request.getParameter("dateOfBirth");
        String gender = request.getParameter("gender");
        String languagePreferences = request.getParameter("languagePreferences");

        // Fetch course details from hidden fields
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        String courseName = request.getParameter("courseNameHidden");
        String instructor = request.getParameter("instructorHidden");
        double coursePrice = Double.parseDouble(request.getParameter("coursePriceHidden"));
        String duration = request.getParameter("durationHidden");

        // Print course name to console
        System.out.println("Course Name: " + courseName);

        // Create a new EnrollmentDetails object
        EnrollmentDetails enrollmentDetails = new EnrollmentDetails();
        enrollmentDetails.setFullName(fullName);
        enrollmentDetails.setEmail(email);
        enrollmentDetails.setPhoneNumber(phoneNumber);
        enrollmentDetails.setCity(city);
        enrollmentDetails.setState(state);
        enrollmentDetails.setCountry(country);
        enrollmentDetails.setDateOfBirth(dateOfBirth);
        enrollmentDetails.setGender(gender);
        enrollmentDetails.setLanguagePreferences(languagePreferences);
        enrollmentDetails.setCourseId(courseId);
        enrollmentDetails.setCourseName(courseName);
        enrollmentDetails.setInstructor(instructor);
        enrollmentDetails.setCoursePrice(coursePrice);
        enrollmentDetails.setDuration(duration);
        enrollmentDetails.setEnrollmentDatetime(new Date()); // Assuming current timestamp

        // Save enrollment details to the database
        saveEnrollmentDetails(enrollmentDetails);
        
        request.setAttribute("fullName", fullName);
        request.setAttribute("email", email);
        request.setAttribute("courseName", courseName);

        // Forward to sendregistermail.jsp for sending confirmation email
        RequestDispatcher dispatcher = request.getRequestDispatcher("/sendresgistermail.jsp");
        dispatcher.forward(request, response);
    }

    

    private void saveEnrollmentDetails(EnrollmentDetails enrollmentDetails) {
        Session session = factory.openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            // Save the enrollmentDetails object
            session.save(enrollmentDetails);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    @Override
    public void destroy() {
        // Close Hibernate session factory during servlet shutdown
        factory.close();
        super.destroy();
    }
}
