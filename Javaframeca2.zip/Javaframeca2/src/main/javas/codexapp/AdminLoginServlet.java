package codexapp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get user input from the form
        String username = request.getParameter("username");
      
        String password = request.getParameter("password");

        // Check if admin credentials match
        if (isValidAdmin(username, password)) {
            // Redirect to adminpanel.jsp if credentials are valid
            HttpSession session = request.getSession();
            session.setAttribute("adminUsername", username);
            response.sendRedirect("adminpanel.jsp");
        } else {
            // Set an error attribute in the request
            request.setAttribute("error", "invalid");

            // Forward back to the login page
            request.getRequestDispatcher("adminlogin.jsp").forward(request, response);
        }
    }

    private boolean isValidAdmin(String username,  String password) {
        // Implement your logic to check if the provided credentials match the admin details
        // This could involve checking against a database or some predefined values
        // For simplicity, let's assume a hardcoded admin username, email, and password
        String adminUsername = "nik";
        
        String adminPassword = "nds";

        return username.equals(adminUsername) && password.equals(adminPassword);
    }
}
