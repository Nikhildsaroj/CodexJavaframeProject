
<!DOCTYPE html>
<html>
<head>
    <title>Sign Up Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <style>
        body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-image: url('https://images.pexels.com/photos/3183132/pexels-photo-3183132.jpeg?auto=compress&cs=tinysrgb');
  background-size: cover;
  background-attachment: fixed;
}

        .container {
  position: absolute;
  top: 70%;
  left: 50%;
  transform: translate(-50%, -50%);

            max-width:auto;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
        }
        h1 {
            text-align: center;
        }
        form {
            display: auto;
            flex-direction: column;
            margin-top: 20px;
            background-color: white;
            padding:30px; 
            border-radius:5px
        }
        label {
            margin-bottom: 10px;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color:#4CAF50; 
            color:white; 
            padding:12px 20px; 
            border:none; 
            border-radius:4px; 
            cursor:pointer
        }
        input[type="submit"]:hover {
            background-color:#45a049
        }
form div {
    display:flex; 
    flex-direction:column
}
form div label {
    flex-basis:auto
}
form div input[type="text"],
form div input[type="email"],
form div input[type="password"] {
    flex-basis:auto
}
form div span.error {
    color:red; 
    font-size:.8em; 
    font-style:italic; 
    margin-left:auto
}
label.error {
    color:red
}
.eye {
    cursor:pointer
}

@media (max-width:500px) {
    .container {
      width:90%
    }
}
.eye-container{
    position:relative
}
.eye-container i{
    position:absolute;
    right:-25px;
    top:-5px
}
input[type='password']{
    padding-right:25px
}
    </style>
</head>
<body>
    <div class="container">
        <h1>Sign Up</h1>
<h2>"The best way to predict your future is to create it" - Abraham Lincoln</h2>
        <form id="signup-form" action="Ca2 Database.php" method="post" >
        
             <div>
                 <label for="name">Name*:</label>
                 <input type="text" id="name" name="name" required oninput='validateName()'>
                 <span id='name-error' class='error'></span>
             </div>

             <div>
                 <label for="email">Email*:</label>
                 <input type="email" id="email" name="email" required oninput='validateEmail()'>
                 <span id='email-error' class='error'></span>
             </div>

             <div>
                 <label for="contact">Contact*:</label>
                 <input type="text" id="contact" name="contact" required oninput='validateContact()'>
                 <span id='contact-error' class='error'></span>
             </div>

             <div class='eye-container'>
                 <label for="password">Password*:</label>
                 <input type="password" id="password" name="password" required oninput='temporarilyShowPassword(event); validatePassword()'>
                 <!-- Added Font Awesome eye icon to show/hide password -->
                 <i class='eye fas fa-eye-slash' onclick='togglePasswordVisibility("password")'></i> 
                 <span id='password-error' class='error'></span>
             </div>

             <div class='eye-container'>
                 <label for="confirm-password">Confirm Password*:</label>
                 <input type="password" id="confirm-password" name="confirm-password" required oninput='temporarilyShowPassword(event); validateConfirmPassword()'>
                 <!-- Added Font Awesome eye icon to show/hide confirm password -->
                 <i class='eye fas fa-eye-slash' onclick='togglePasswordVisibility("confirm-password")'></i> 
                 <span id='confirm-password-error' class='error'></span>
             </div>

             <input type="submit" value="student_info">
            
             <!-- Removed the Sign up with Google button -->
            
        </form>         
    </div>

    <script>

function togglePasswordVisibility(passwordFieldId) {
    var passwordField = document.getElementById(passwordFieldId);
    var eyeIcon = passwordField.parentElement.querySelector('.eye');
    
    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    } else {
        passwordField.type = 'password';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    }
}

function temporarilyShowPassword(event) {
    var passwordField = event.target;
    var lastValue = passwordField.value.slice(-1);
    
    passwordField.type = 'text';
    setTimeout(function() { passwordField.type = 'password'; },1000);
}

function validateName() {
    var name = document.getElementById("name").value.trim();
    
    if (!/^[a-zA-Z\s]*$/.test(name)) {
        document.getElementById('name-error').innerHTML = 'Name must contain only letters and spaces.';
        document.querySelector('label[for="name"]').classList.add('error');
        return false;
    } else {
        document.getElementById('name-error').innerHTML = '';
        document.querySelector('label[for="name"]').classList.remove('error');
        return true;
    }
}

function validateEmail() {
    var email = document.getElementById("email").value.trim();
    
    if (!/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email)) {
        document.getElementById('email-error').innerHTML = 'Email must be in a valid format.';
        document.querySelector('label[for="email"]').classList.add('error');
        return false;
    } else {
        document.getElementById('email-error').innerHTML = '';
        document.querySelector('label[for="email"]').classList.remove('error');
        return true;
    }
}

function validateContact() {
    var contact = document.getElementById("contact").value.trim();
    
    if (!/^\d{10}$/.test(contact)) {
        document.getElementById('contact-error').innerHTML = 'Contact number must be exactly ten digits long.';
        document.querySelector('label[for="contact"]').classList.add('error');
        return false;
    } else {
        document.getElementById('contact-error').innerHTML = '';
        document.querySelector('label[for="contact"]').classList.remove('error');
        return true;
    }
}

function validatePassword() {
    var password = document.getElementById("password").value.trim();
    
    if (password.length < 8) {
        document.getElementById('password-error').innerHTML = 'Password must be at least 8 characters long.';
        document.querySelector('label[for="password"]').classList.add('error');
        return false;
    } else {
        document.getElementById('password-error').innerHTML = '';
        document.querySelector('label[for="password"]').classList.remove('error');
        return true;
    }
}

function validateConfirmPassword() {
    var password = document.getElementById("password").value.trim();
    var confirmPassword = document.getElementById("confirm-password").value.trim();
    
    if (confirmPassword !== password) {
        document.getElementById('confirm-password-error').innerHTML = 'Confirm password must match password.';
        document.querySelector('label[for="confirm-password"]').classList.add('error');
        return false;
    } else {
        document.getElementById('confirm-password-error').innerHTML = '';
        document.querySelector('label[for="confirm-password"]').classList.remove('error');
        return true;
    }
}

</script>
 
</body>
</html>
