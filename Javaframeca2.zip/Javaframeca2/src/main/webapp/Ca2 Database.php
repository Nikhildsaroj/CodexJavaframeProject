<?php
$servername = "localhost"; // Change this to your MySQL server hostname
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$dbName = "CA2_Database"; // Desired database name
$tableName = "Signup_info"; // Desired table name

// Create a connection to MySQL
$conn = new mysqli($servername, $username, $password, $dbName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to create a new table without the "id" column
$sqlCreateTable = "CREATE TABLE IF NOT EXISTS $tableName (
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    contact VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL
)";

if ($conn->query($sqlCreateTable) === TRUE) {
    echo "Table $tableName created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $contact = $_POST["contact"];
    $password = $_POST["password"];

    // SQL query to insert data into the table
    $sqlInsert = "INSERT INTO $tableName (name, email, contact, password) 
                  VALUES ('$name', '$email', '$contact', '$password')";

    if ($conn->query($sqlInsert) === TRUE) {
        echo "Data inserted successfully";
    } else {
        echo "Error inserting data: " . $conn->error;
    }
}

// Close the connection
$conn->close();
?>